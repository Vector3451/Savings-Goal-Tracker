package com.savings.tracker.util;

import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;

public class DatabaseSetup {
    public static void setupDatabase() {
        try (Connection conn = DBUtil.getConnection();
             Statement stmt = conn.createStatement()) {
            
            // Create tables if they don't exist
            try {
                stmt.execute("CREATE TABLE IF NOT EXISTS users (\n" +
                "    user_id INT AUTO_INCREMENT PRIMARY KEY,\n" +
                "    name VARCHAR(100) NOT NULL\n" +
                ") ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
                System.out.println("Created users table");
            } catch (SQLException e) {
                System.err.println("Error creating users table: " + e.getMessage());
            }

            try {
                stmt.execute("CREATE TABLE IF NOT EXISTS expenses (" +
                "    expense_id INT AUTO_INCREMENT PRIMARY KEY," +
                "    user_id INT NOT NULL," +
                "    amount DECIMAL(10,2) NOT NULL," +
                "    description TEXT," +
                "    category VARCHAR(50) NOT NULL," +
                "    expense_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP," +
                "    is_fixed BOOLEAN DEFAULT FALSE," +
                "    FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE" +
                ") ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
                System.out.println("Created expenses table");
            } catch (SQLException e) {
                System.err.println("Error creating expenses table: " + e.getMessage());
            }

            try {
                stmt.execute("CREATE TABLE IF NOT EXISTS income (\n" +
                "    income_id INT AUTO_INCREMENT PRIMARY KEY,\n" +
                "    user_id INT NOT NULL,\n" +
                "    amount DECIMAL(10,2) NOT NULL,\n" +
                "    source VARCHAR(100) NOT NULL,\n" +
                "    frequency ENUM('One-time', 'Weekly', 'Bi-weekly', 'Monthly'),\n" +
                "    income_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,\n" +
                "    FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE\n" +
                ") ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
                System.out.println("Created income table");
            } catch (SQLException e) {
                System.err.println("Error creating income table: " + e.getMessage());
            }

            try {
                stmt.execute("CREATE TABLE IF NOT EXISTS goals (" +
                "    goal_id INT AUTO_INCREMENT PRIMARY KEY," +
                "    user_id INT NOT NULL," +
                "    name VARCHAR(100) NOT NULL," +
                "    description TEXT," +
                "    target_amount DECIMAL(10,2) NOT NULL," +
                "    current_amount DECIMAL(10,2) DEFAULT 0.00," +
                "    target_date DATE," +
                "    is_fixed BOOLEAN DEFAULT FALSE," +
                "    status ENUM('In Progress', 'Completed', 'Missed') DEFAULT 'In Progress'," +
                "    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP," +
                "    FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE" +
                ") ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
                System.out.println("Created goals table");
            } catch (SQLException e) {
                System.err.println("Error creating goals table: " + e.getMessage());
            }

            try {
                stmt.execute("CREATE TABLE IF NOT EXISTS notifications (" +
                "    notification_id INT AUTO_INCREMENT PRIMARY KEY," +
                "    user_id INT NOT NULL," +
                "    message TEXT NOT NULL," +
                "    type ENUM('INFO', 'WARNING', 'ALERT') DEFAULT 'INFO'," +
                "    is_read BOOLEAN DEFAULT FALSE," +
                "    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP," +
                "    FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE" +
                ") ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
                System.out.println("Created notifications table");
            } catch (SQLException e) {
                System.err.println("Error creating notifications table: " + e.getMessage());
            }
            
            // Insert a default user if none exists
            try {
                stmt.execute("INSERT IGNORE INTO users (user_id, name) " +
                           "VALUES (1, 'Default User')");
                System.out.println("Ensured default user exists");
            } catch (SQLException e) {
                System.err.println("Error creating default user: " + e.getMessage());
            }
            
            System.out.println("Database setup completed successfully!");
            
        } catch (SQLException e) {
            System.err.println("Error setting up database: " + e.getMessage());
            e.printStackTrace();
        }
    }
}
