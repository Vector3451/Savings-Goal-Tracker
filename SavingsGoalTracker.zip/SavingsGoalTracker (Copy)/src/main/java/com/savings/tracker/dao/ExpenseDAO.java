package com.savings.tracker.dao;
import com.savings.tracker.model.Expense;
import com.savings.tracker.util.DBUtil;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
public class ExpenseDAO { 
    public void addExpense(Expense expense) throws SQLException {
        String sql = "INSERT INTO expenses (user_id, amount, category, expense_date, description, is_fixed) " +
                    "VALUES (?, ?, ?, ?, ?, ?)";
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql, new String[]{"expense_id"})) {
            pstmt.setInt(1, expense.getUserId());
            pstmt.setDouble(2, expense.getAmount());
            pstmt.setString(3, expense.getCategory());
            pstmt.setDate(4, expense.getExpenseDate());
            pstmt.setString(5, expense.getDescription());
            pstmt.setBoolean(6, expense.isFixed());
            pstmt.executeUpdate();
            
            // Get the generated expense_id
            ResultSet rs = pstmt.getGeneratedKeys();
            if (rs.next()) {
                expense.setExpenseId(rs.getInt(1));
            }
        }
    }
    public List<Expense> getAllExpenses(int userId) throws SQLException {
        List<Expense> expenses = new ArrayList<>();
        String sql = "SELECT * FROM expenses WHERE user_id = ? ORDER BY expense_date DESC";   
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, userId);
            ResultSet rs = pstmt.executeQuery();
            while (rs.next()) {
                Expense expense = new Expense(
                    rs.getInt("user_id"),
                    rs.getDouble("amount"),
                    rs.getString("category"),
                    rs.getString("description"),
                    rs.getBoolean("is_fixed")
                );
                expense.setExpenseId(rs.getInt("expense_id"));
                expense.setExpenseDate(rs.getDate("expense_date"));
                expenses.add(expense);
            }
        }
        return expenses;
    }
    public double getTotalExpenses(int userId) throws SQLException {
        String sql = "SELECT SUM(amount) as total FROM expenses WHERE user_id = ?";
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, userId);
            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                return rs.getDouble("total");
            }
            return 0.0;
        }
    }
}