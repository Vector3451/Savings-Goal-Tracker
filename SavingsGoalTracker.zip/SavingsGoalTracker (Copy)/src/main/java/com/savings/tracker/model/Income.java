package com.savings.tracker.model;
import java.sql.Date;
public class Income {
    private int incomeId;
    private int userId;
    private double amount;
    private String source;
    private String frequency; 
    private Date incomeDate;
    public Income(int userId, double amount, String source, String frequency) {
        this.userId = userId;
        this.amount = amount;
        this.source = source;
        this.frequency = frequency;
        this.incomeDate = new Date(System.currentTimeMillis());
    }
    public int getIncomeId() { 
        return incomeId; 
    }
    public void setIncomeId(int incomeId) {
        this.incomeId = incomeId;
    }
    public int getUserId() {
        return userId; 
    }
    public void setUserId(int userId) { 
        this.userId = userId; 
    }
    public double getAmount() { 
        return amount; 
    }
    public void setAmount(double amount) { 
        this.amount = amount; 
    }
    public String getSource() { 
        return source; 
    }
    public void setSource(String source) { 
        this.source = source; 
    }
    public String getFrequency() { 
        return frequency; 
    }
    public void setFrequency(String frequency) { 
        this.frequency = frequency; 
    }
    public Date getIncomeDate() { 
        return incomeDate; 
    }
    public void setIncomeDate(Date incomeDate) { 
        this.incomeDate = incomeDate; 
    }
}