package com.savings.tracker.model;
import java.sql.Date;
public class Expense {
    private int expenseId;
    private int userId;
    private double amount;
    private String category;
    private Date expenseDate;
    private String description;
    private boolean isFixed;
    public Expense(int userId, double amount, String category, String description, boolean isFixed) {
        this.userId = userId;
        this.amount = amount;
        this.category = category;
        this.description = description;
        this.isFixed = isFixed;
        this.expenseDate = new Date(System.currentTimeMillis());
    }
    // Getters and Setters
    public int getExpenseId() { 
        return expenseId; 
    }
    public void setExpenseId(int expenseId) { 
        this.expenseId = expenseId; 
    }
    public int getUserId() { 
        return userId; 
    }
    public void setUserId(int userId) { 
        this.userId = userId; 
    }
    public double getAmount() { 
        return amount; 
    }
    public void setAmount(double amount) { 
        this.amount = amount; 
    }
    public String getCategory() { 
        return category; 
    }
    public void setCategory(String category) { 
        this.category = category; 
    }
    public Date getExpenseDate() { 
        return expenseDate; 
    }
    public void setExpenseDate(Date expenseDate) { 
        this.expenseDate = expenseDate; 
    }
    public String getDescription() { 
        return description; 
    }
    public void setDescription(String description) { 
        this.description = description; 
    }
    public boolean isFixed() { 
        return isFixed; 
    }
    public void setFixed(boolean fixed) { 
        isFixed = fixed; 
    }
}