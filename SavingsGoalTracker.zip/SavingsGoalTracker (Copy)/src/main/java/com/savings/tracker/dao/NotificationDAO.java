package com.savings.tracker.dao;

import com.savings.tracker.model.Notification;
import com.savings.tracker.util.DBUtil;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class NotificationDAO {
    
    public static void addNotification(Notification notification) throws SQLException {
        String sql = "INSERT INTO notifications (user_id, message, type, is_read, created_at) " +
                    "VALUES (?, ?, ?, ?, ?)";
        
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql, new String[]{"notification_id"})) {
            
            pstmt.setInt(1, notification.getUserId());
            pstmt.setString(2, notification.getMessage());
            pstmt.setString(3, notification.getType());
            pstmt.setInt(4, notification.isRead() ? 1 : 0);
            pstmt.setTimestamp(5, notification.getCreatedAt());
            
            pstmt.executeUpdate();
            
            ResultSet rs = pstmt.getGeneratedKeys();
            if (rs.next()) {
                notification.setNotificationId(rs.getInt(1));
            }
        }
    }

    public static List<Notification> getUnreadNotifications(int userId) throws SQLException {
        List<Notification> notifications = new ArrayList<>();
        String sql = "SELECT notification_id, user_id, message, type, is_read, created_at " +
                    "FROM notifications " +
                    "WHERE user_id = ? AND is_read = 0 " +
                    "ORDER BY created_at DESC";
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setInt(1, userId);
            ResultSet rs = pstmt.executeQuery();
            
            while (rs.next()) {
                Notification notification = new Notification(
                    rs.getInt("user_id"),
                    rs.getString("message"),
                    rs.getString("type")
                );
                notification.setNotificationId(rs.getInt("notification_id"));
                notification.setRead(rs.getInt("is_read") == 1);
                notification.setCreatedAt(new Timestamp(rs.getTimestamp("created_at").getTime()));
                notifications.add(notification);
            }
        }
        return notifications;
    }

    public static List<Notification> getAllNotifications(int userId) throws SQLException {
        List<Notification> notifications = new ArrayList<>();
        String sql = "SELECT notification_id, user_id, message, type, is_read, created_at " +
                    "FROM notifications " +
                    "WHERE user_id = ? " +
                    "ORDER BY created_at DESC";
        
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setInt(1, userId);
            ResultSet rs = pstmt.executeQuery();
            
            while (rs.next()) {
                Notification notification = new Notification(
                    rs.getInt("user_id"),
                    rs.getString("message"),
                    rs.getString("type")
                );
                notification.setNotificationId(rs.getInt("notification_id"));
                notification.setRead(rs.getInt("is_read") == 1);
                notification.setCreatedAt(new Timestamp(rs.getTimestamp("created_at").getTime()));
                notifications.add(notification);
            }
        }
        return notifications;
    }

    public static void markAsRead(int notificationId) throws SQLException {
        String sql = "UPDATE notifications SET is_read = 1 WHERE notification_id = ?";
        
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setInt(1, notificationId);
            pstmt.executeUpdate();
        }
    }

    public static int getUnreadNotificationCount(int userId) throws SQLException {
        String sql = "SELECT COUNT(*) as count FROM notifications WHERE user_id = ? AND is_read = 0";
        
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setInt(1, userId);
            ResultSet rs = pstmt.executeQuery();
            
            if (rs.next()) {
                return rs.getInt("count");
            }
            return 0;
        }
    }
    
    public static void markAllAsRead(int userId) throws SQLException {
        String sql = "UPDATE notifications SET is_read = 1 WHERE user_id = ?";
        
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setInt(1, userId);
            pstmt.executeUpdate();
        }
    }

    public static void deleteOldNotifications(int userId, int daysOld) throws SQLException {
        String sql = "DELETE FROM notifications WHERE user_id = ? AND created_at < ?";
        
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            Timestamp cutoff = new Timestamp(System.currentTimeMillis() - (daysOld * 24L * 60 * 60 * 1000));
            pstmt.setInt(1, userId);
            pstmt.setTimestamp(2, cutoff);
            pstmt.executeUpdate();
        }
    }

    // Helper method to generate notifications for goals
    public static void checkAndGenerateGoalNotifications(int userId) throws SQLException {
        // Get all active goals
        String sql = "SELECT goal_id, name, target_date, current_amount, target_amount " +
                    "FROM goals " +
                    "WHERE user_id = ? AND status = 'In Progress'";
        
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setInt(1, userId);
            ResultSet rs = pstmt.executeQuery();
            
            while (rs.next()) {
                String goalName = rs.getString("name");
                Date targetDate = rs.getDate("target_date");
                double currentAmount = rs.getDouble("current_amount");
                double targetAmount = rs.getDouble("target_amount");
                
                // Check for goals near deadline (7 days)
                long daysUntilTarget = (targetDate.getTime() - System.currentTimeMillis()) / (1000 * 60 * 60 * 24);
                if (daysUntilTarget > 0 && daysUntilTarget <= 7) {
                    addNotification(new Notification(
                        userId,
                        String.format("Goal '%s' is due in %d days! Progress: %.1f%%",
                            goalName, daysUntilTarget, (currentAmount / targetAmount * 100)),
                        "WARNING"
                    ));
                }
                
                // Check for goals that are behind schedule
                double expectedProgress = 1.0 - (daysUntilTarget / 30.0); // Assuming monthly goals
                double actualProgress = currentAmount / targetAmount;
                if (expectedProgress > actualProgress && expectedProgress <= 1.0) {
                    addNotification(new Notification(
                        userId,
                        String.format("Goal '%s' is behind schedule. Current progress: %.1f%%, Expected: %.1f%%",
                            goalName, actualProgress * 100, expectedProgress * 100),
                        "ALERT"
                    ));
                }
            }
        }
    }
}
