package com.savings.tracker.model;

import java.sql.Date;

public class Goal {
    private int goalId;
    private int userId;
    private String name;
    private String description;
    private double targetAmount;
    private double currentAmount;
    private Date targetDate;
    private boolean isFixed;
    private String status; // "In Progress", "Completed", "Missed"

    // Constructor for creating a new goal
    public Goal(int userId, String name, String description, double targetAmount, Date targetDate, boolean isFixed) {
        this.userId = userId;
        this.name = name;
        this.description = description;
        this.targetAmount = targetAmount;
        this.currentAmount = 0.0;
        this.targetDate = targetDate;
        this.isFixed = isFixed;
        this.status = "In Progress";
    }

    // Constructor for database retrieval
    public Goal(int goalId, int userId, String name, String description, double targetAmount, double currentAmount, Date targetDate, boolean isFixed, String status) {
        this.goalId = goalId;
        this.userId = userId;
        this.name = name;
        this.description = description;
        this.targetAmount = targetAmount;
        this.currentAmount = currentAmount;
        this.targetDate = targetDate;
        this.isFixed = isFixed;
        this.status = status;
    }

    // Getters and Setters
    public int getGoalId() { return goalId; }
    public void setGoalId(int goalId) { this.goalId = goalId; }
    
    public int getUserId() { return userId; }
    public void setUserId(int userId) { this.userId = userId; }
    
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
    
    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }
    
    public double getTargetAmount() { return targetAmount; }
    public void setTargetAmount(double targetAmount) { this.targetAmount = targetAmount; }
    
    public double getCurrentAmount() { return currentAmount; }
    public void setCurrentAmount(double currentAmount) { this.currentAmount = currentAmount; }
    
    public Date getTargetDate() { return targetDate; }
    public void setTargetDate(Date targetDate) { this.targetDate = targetDate; }
    
    public boolean isFixed() { return isFixed; }
    public void setFixed(boolean isFixed) { this.isFixed = isFixed; }
    
    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }
    
    // Calculate progress percentage
    public double getProgressPercentage() {
        if (targetAmount == 0) return 0;
        return (currentAmount / targetAmount) * 100;
    }

    // Check if goal is achieved
    public boolean isAchieved() {
        return currentAmount >= targetAmount;
    }

    // Check if goal is overdue
    public boolean isOverdue() {
        return !isAchieved() && targetDate.before(new Date(System.currentTimeMillis()));
    }
}
