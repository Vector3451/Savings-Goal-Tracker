package com.savings.tracker.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class DBUtil {
    private static final String BASE_URL = "jdbc:mysql://127.0.0.1:3306";
    private static final String DB_NAME = "savings_tracker";
    private static final String URL = BASE_URL + "/" + DB_NAME + "?useSSL=false&serverTimezone=UTC&allowPublicKeyRetrieval=true";
    private static final String USER = "root";
    private static final String PASSWORD = "mysecret";

    static {
        try {
            // Explicitly load the MySQL JDBC driver
            Class.forName("com.mysql.cj.jdbc.Driver");
            System.out.println("MySQL JDBC Driver Registered!");
            
            // First connect without database to create it if needed
            try (Connection conn = DriverManager.getConnection(BASE_URL + "?useSSL=false&serverTimezone=UTC&allowPublicKeyRetrieval=true", USER, PASSWORD);
                 Statement stmt = conn.createStatement()) {
                
                // Create database if it doesn't exist
                stmt.execute("CREATE DATABASE IF NOT EXISTS " + DB_NAME + " CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci");
                System.out.println("Database " + DB_NAME + " is ready");
                
                // Now connect to the specific database
                try (Connection dbConn = getConnection()) {
                    System.out.println("Successfully connected to " + DB_NAME + " database!");
                }
            }
        } catch (ClassNotFoundException e) {
            System.err.println("MySQL JDBC Driver not found.");
            e.printStackTrace();
        } catch (SQLException e) {
            System.err.println("Failed to connect to MySQL database: " + e.getMessage());
            e.printStackTrace();
        }
    }

    public static Connection getConnection() throws SQLException {
        return DriverManager.getConnection(URL, USER, PASSWORD);
    }
}