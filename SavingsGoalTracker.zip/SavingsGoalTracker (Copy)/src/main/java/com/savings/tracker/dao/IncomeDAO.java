package com.savings.tracker.dao;
import com.savings.tracker.model.Income;
import com.savings.tracker.util.DBUtil;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
public class IncomeDAO {
    public void addIncome(Income income) throws SQLException {
        String sql = "INSERT INTO income (user_id, amount, source, frequency, income_date) VALUES (?, ?, ?, ?, ?)";
        try (Connection conn = DBUtil.getConnection();
            PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, income.getUserId());
            pstmt.setDouble(2, income.getAmount());
            pstmt.setString(3, income.getSource());
            pstmt.setString(4, income.getFrequency());
            pstmt.setDate(5, income.getIncomeDate());       
            pstmt.executeUpdate();
        }
    }
    public List<Income> getAllIncome(int userId) throws SQLException {
        List<Income> incomes = new ArrayList<>();
        String sql = "SELECT * FROM income WHERE user_id = ? ORDER BY income_date DESC";
        try (Connection conn = DBUtil.getConnection();
            PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, userId);
            ResultSet rs = pstmt.executeQuery();        
            while (rs.next()) {
                Income income = new Income(
                    rs.getInt("user_id"),
                    rs.getDouble("amount"),
                    rs.getString("source"),
                    rs.getString("frequency")
                );
                income.setIncomeId(rs.getInt("income_id"));
                income.setIncomeDate(rs.getDate("income_date"));
                incomes.add(income);
            }
        }
        return incomes;
    }
    public double getTotalIncome(int userId) throws SQLException {
        String sql = "SELECT SUM(amount) as total FROM income WHERE user_id = ?";
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, userId);
            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                return rs.getDouble("total");
            }
            return 0.0;
        }
    }
}