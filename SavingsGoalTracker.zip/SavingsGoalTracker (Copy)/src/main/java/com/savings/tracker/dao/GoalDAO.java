package com.savings.tracker.dao;

import com.savings.tracker.model.Goal;
import com.savings.tracker.util.DBUtil;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class GoalDAO {
    
    public void addGoal(Goal goal) throws SQLException {
        String sql = "INSERT INTO goals (user_id, name, description, target_amount, current_amount, target_date, is_fixed, status) " +
                    "VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
        
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql, new String[]{"goal_id"})) {
            
            pstmt.setInt(1, goal.getUserId());
            pstmt.setString(2, goal.getName());
            pstmt.setString(3, goal.getDescription());
            pstmt.setDouble(4, goal.getTargetAmount());
            pstmt.setDouble(5, goal.getCurrentAmount());
            pstmt.setDate(6, goal.getTargetDate());
            pstmt.setBoolean(7, goal.isFixed());
            pstmt.setString(8, goal.getStatus());
            
            pstmt.executeUpdate();
            
            ResultSet rs = pstmt.getGeneratedKeys();
            if (rs.next()) {
                goal.setGoalId(rs.getInt(1));
            }
        }
    }

    public List<Goal> getAllGoals(int userId) throws SQLException {
        List<Goal> goals = new ArrayList<>();
        String sql = "SELECT * FROM goals WHERE user_id = ? ORDER BY target_date";
        
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setInt(1, userId);
            ResultSet rs = pstmt.executeQuery();
            
            while (rs.next()) {
                // Get the date as a string first, then parse it
                String targetDateStr = rs.getString("target_date");
                Date targetDate = null;
                if (targetDateStr != null && !targetDateStr.isEmpty()) {
                    try {
                        targetDate = Date.valueOf(targetDateStr);
                    } catch (IllegalArgumentException e) {
                        System.err.println("Error parsing date: " + targetDateStr);
                    }
                }
                Goal goal = new Goal(
                    rs.getInt("goal_id"),
                    rs.getInt("user_id"),
                    rs.getString("name"),
                    rs.getString("description"),
                    rs.getDouble("target_amount"),
                    rs.getDouble("current_amount"),
                    targetDate,
                    rs.getBoolean("is_fixed"),
                    rs.getString("status"));
                goals.add(goal);
            }
        }
        return goals;
    }

    public void updateGoalProgress(int goalId, double amount) throws SQLException {
        // First get the current values
        String selectSql = "SELECT current_amount, target_amount, target_date FROM goals WHERE goal_id = ?";
        
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement selectStmt = conn.prepareStatement(selectSql)) {
            
            selectStmt.setInt(1, goalId);
            ResultSet rs = selectStmt.executeQuery();
            
            if (rs.next()) {
                double currentAmount = rs.getDouble("current_amount");
                double targetAmount = rs.getDouble("target_amount");
                double newAmount = currentAmount + amount;
                
                // Cap the amount at target amount if we would exceed it
                if (newAmount > targetAmount) {
                    newAmount = targetAmount;
                    amount = targetAmount - currentAmount; // Adjust the amount being added
                }
                
                String updateSql = "UPDATE goals SET current_amount = ?, " +
                                 "status = CASE " +
                                 "WHEN ? >= ? THEN 'Completed' " +
                                 "WHEN CURRENT_DATE > target_date THEN 'Missed' " +
                                 "WHEN CURRENT_DATE < target_date THEN 'In Progress' " +
                                 "ELSE 'In Progress' END " +
                                 "WHERE goal_id = ?";
                
                try (PreparedStatement updateStmt = conn.prepareStatement(updateSql)) {
                    updateStmt.setDouble(1, newAmount);
                    updateStmt.setDouble(2, newAmount);
                    updateStmt.setDouble(3, targetAmount);
                    updateStmt.setInt(4, goalId);
                    updateStmt.executeUpdate();
                }
            }
        }
    }

    public void updateGoal(Goal goal) throws SQLException {
        String sql = "UPDATE goals SET name = ?, description = ?, target_amount = ?, target_date = ?, is_fixed = ? WHERE goal_id = ?";
        
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setString(1, goal.getName());
            pstmt.setString(2, goal.getDescription());
            pstmt.setDouble(3, goal.getTargetAmount());
            pstmt.setDate(4, goal.getTargetDate());
            pstmt.setBoolean(5, goal.isFixed());
            pstmt.setInt(6, goal.getGoalId());
            
            int rowsAffected = pstmt.executeUpdate();
            
            if (rowsAffected == 0) {
                throw new SQLException("No goal found with ID: " + goal.getGoalId());
            }
        }
    }

    public void deleteGoal(int goalId) throws SQLException {
        String sql = "DELETE FROM goals WHERE goal_id = ?";
        
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setInt(1, goalId);
            int rowsAffected = pstmt.executeUpdate();
            
            if (rowsAffected == 0) {
                throw new SQLException("No goal found with ID: " + goalId);
            }
        }
    }
}
