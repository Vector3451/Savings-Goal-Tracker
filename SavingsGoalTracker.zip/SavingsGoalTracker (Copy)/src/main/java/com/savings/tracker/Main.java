package com.savings.tracker;

import com.savings.tracker.dao.ExpenseDAO;
import com.savings.tracker.dao.GoalDAO;
import com.savings.tracker.dao.IncomeDAO;
import com.savings.tracker.dao.NotificationDAO;
import com.savings.tracker.model.Expense;
import com.savings.tracker.model.Goal;
import com.savings.tracker.model.Income;
import com.savings.tracker.model.Notification;
import com.savings.tracker.util.DatabaseSetup;

import java.sql.Date;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.List;
import java.util.Scanner;

public class Main {
    private static final int DEFAULT_USER_ID = 1;

    static {
        try {
            DatabaseSetup.setupDatabase();
        } catch (Exception e) {
            System.err.println("Failed to setup database: " + e.getMessage());
            e.printStackTrace();
            System.exit(1);
        }
    }

    private static void handleAddExpense(Scanner scanner) {
        try {
            System.out.println("\n======== Add New Expense ========");
            System.out.print("Enter amount: ");
            double amount = Double.parseDouble(scanner.nextLine().trim());

            System.out.print("Enter category (Food, Transport, Bills, etc.): ");
            String category = scanner.nextLine().trim();

            System.out.print("Enter description: ");
            String description = scanner.nextLine().trim();

            System.out.print("Is this a fixed expense? (y/n): ");
            boolean isFixed = scanner.nextLine().trim().toLowerCase().startsWith("y");

            Expense expense = new Expense(DEFAULT_USER_ID, amount, category, description, isFixed);
            new ExpenseDAO().addExpense(expense);

            // Add notification for expense
            String message = String.format("Expense of $%.2f added to category: %s", amount, category);
            addNotification(message, "EXPENSE");

            // Add warning for large expenses
            if (amount > 1000) {
                addNotification("Large expense recorded: $" + amount + " for " + category, "WARNING");
            }

            System.out.println("Expense added successfully!");

        } catch (NumberFormatException e) {
            System.out.println("Invalid amount entered. Please enter a valid number.");
        } catch (SQLException e) {
            System.out.println("Error adding expense: " + e.getMessage());
            addNotification("Failed to add expense: " + e.getMessage(), "ERROR");
        }
    }

    private static void handleAddIncome(Scanner scanner) {
        System.out.println("\n======== Add New Income ========");
        System.out.print("Enter amount: ");
        double amount = Double.parseDouble(scanner.nextLine().trim());
        
        System.out.print("Enter source (Salary, Freelance, etc.): ");
        String source = scanner.nextLine().trim();
        
        System.out.print("Enter frequency (Monthly, Annual, One-time): ");
        String frequency = scanner.nextLine().trim();
        
        try {
            Income income = new Income(DEFAULT_USER_ID, amount, source, frequency);
            new IncomeDAO().addIncome(income);
            
            // Add notification for income
            String message = String.format("%s income of $%.2f added from %s", 
                frequency, amount, source);
            addNotification(message, "INCOME");
            
            // Add notification for significant income
            if (amount > 5000) {
                addNotification("Significant income recorded: $" + amount, "INFO");
            }
            
            System.out.println("Income added successfully!");
        } catch (NumberFormatException e) {
            System.out.println("Invalid amount entered. Please enter a valid number.");
        } catch (SQLException e) {
            System.out.println("Error adding income: " + e.getMessage());
            addNotification("Failed to add income: " + e.getMessage(), "ERROR");
        }
    }

    private static void handleViewBalance() {
        try {
            System.out.println("\n======== Balance Summary ========");
            ExpenseDAO expenseDAO = new ExpenseDAO();
            IncomeDAO incomeDAO = new IncomeDAO();

            double totalExpenses = expenseDAO.getTotalExpenses(DEFAULT_USER_ID);
            double totalIncome = incomeDAO.getTotalIncome(DEFAULT_USER_ID);
            double balance = totalIncome - totalExpenses;

            System.out.printf("Total Income:   $%,.2f%n", totalIncome);
            System.out.printf("Total Expenses: $%,.2f%n", totalExpenses);
            System.out.println("------------------------");
            System.out.printf("Net Balance:    $%,.2f%n", balance);

            if (balance < 0) {
                System.out.println("⚠️ Warning: You are in deficit!");
            }
        } catch (SQLException e) {
            System.out.println("Error retrieving balance: " + e.getMessage());
        }
    }

    private static void displayGoals(List<Goal> goals) {
        if (goals.isEmpty()) {
            System.out.println("No goals found.");
            return;
        }
        
        System.out.println("\n======== Your Goals ========");
        for (int i = 0; i < goals.size(); i++) {
            Goal goal = goals.get(i);
            double progress = (goal.getCurrentAmount() / goal.getTargetAmount()) * 100;
            System.out.printf("%d. %s%n", i + 1, goal.getName());
            System.out.printf("   Target: $%,.2f%n", goal.getTargetAmount());
            System.out.printf("   Current: $%,.2f (%.1f%%)%n", 
                goal.getCurrentAmount(), 
                progress);
            System.out.printf("   Due: %s%n", goal.getTargetDate());
            System.out.printf("   Status: %s%n%n", goal.getStatus());
        }
    }

    private static Goal selectGoalFromList(Scanner scanner, List<Goal> goals) {
        displayGoals(goals);
        if (goals.isEmpty()) {
            return null;
        }

        System.out.print("Select a goal number: ");
        try {
            int index = Integer.parseInt(scanner.nextLine().trim()) - 1;
            if (index >= 0 && index < goals.size()) {
                return goals.get(index);
            } else {
                System.out.println("Invalid selection.");
                return null;
            }
        } catch (NumberFormatException e) {
            System.out.println("Please enter a valid number.");
            return null;
        }
    }

    private static void handleManageGoals(Scanner scanner) {
        GoalDAO goalDAO = new GoalDAO();

        while (true) {
            System.out.println("\n======== Manage Goals ========");
            System.out.println("1. View All Goals");
            System.out.println("2. Add New Goal");
            System.out.println("3. Update Goal Progress");
            System.out.println("4. Update Goal Details");
            System.out.println("5. Delete Goal");
            System.out.println("6. Back to Main Menu");
            System.out.print("Choose an option: ");

            String input = scanner.nextLine().trim();
            int choice;

            try {
                choice = Integer.parseInt(input);
            } catch (NumberFormatException e) {
                System.out.println("Invalid choice. Please enter a number between 1 and 6.");
                continue;
            }

            try {
                switch (choice) {
                    case 1: {
                        List<Goal> goals = goalDAO.getAllGoals(DEFAULT_USER_ID);
                        displayGoals(goals);
                        break;
                    }

                    case 2: {
                        System.out.println("Enter goal name: ");
                        String name = scanner.nextLine().trim();

                        System.out.println("Enter target amount: ");
                        double targetAmount = Double.parseDouble(scanner.nextLine().trim());

                        System.out.println("Enter target date (YYYY-MM-DD): ");
                        String dateStr = scanner.nextLine().trim();
                        Date targetDate = Date.valueOf(dateStr);

                        System.out.println("Enter description: ");
                        String description = scanner.nextLine().trim();

                        System.out.println("Is this a fixed goal? (y/n): ");
                        boolean isFixed = scanner.nextLine().trim().equalsIgnoreCase("y");

                        try {
                            Goal goal = new Goal(DEFAULT_USER_ID, name, description, targetAmount, targetDate, isFixed);
                            goalDAO.addGoal(goal);
                            
                            // Add notification for new goal
                            String message = String.format("New goal created: %s (Target: $%.2f by %s)", 
                                name, targetAmount, targetDate);
                            addNotification(message, "GOAL");
                            
                            // Check if goal is due soon (within 7 days)
                            long daysUntilDue = (targetDate.getTime() - System.currentTimeMillis()) / (1000 * 60 * 60 * 24);
                            if (daysUntilDue <= 7) {
                                addNotification("Goal '" + name + "' is due in " + daysUntilDue + " days!", "ALERT");
                            }
                            
                            System.out.println("Goal added successfully!");
                        } catch (Exception e) {
                            System.out.println("Error adding goal: " + e.getMessage());
                            addNotification("Failed to add goal: " + e.getMessage(), "ERROR");
                        }
                        break;
                    }

                    case 3: {
                        List<Goal> goals = goalDAO.getAllGoals(DEFAULT_USER_ID);
                        Goal goal = selectGoalFromList(scanner, goals);
                        if (goal != null) {
                            System.out.println("Enter new progress amount: ");
                            double progress = Double.parseDouble(scanner.nextLine().trim());
                            // Update the goal's current amount
                            goal.setCurrentAmount(progress);
                            
                            try {
                                goalDAO.updateGoal(goal);
                                
                                // Add notification for progress update
                                double progressPercent = (progress / goal.getTargetAmount()) * 100;
                                String message = String.format("Progress updated for '%s': $%.2f of $%.2f (%.1f%%)",
                                    goal.getName(), progress, goal.getTargetAmount(), progressPercent);
                                addNotification(message, "GOAL_UPDATE");
                                
                                // Check if goal is completed
                                if (progress >= goal.getTargetAmount()) {
                                    addNotification("🎉 Goal completed: " + goal.getName() + "! 🎉", "SUCCESS");
                                }
                                
                                System.out.println("Progress updated.");
                            } catch (SQLException e) {
                                System.out.println("Error updating goal: " + e.getMessage());
                                addNotification("Failed to update goal progress: " + e.getMessage(), "ERROR");
                            }
                        }
                        break;
                    }

                    case 4: {
                        List<Goal> goals = goalDAO.getAllGoals(DEFAULT_USER_ID);
                        if (goals.isEmpty()) {
                            System.out.println("No goals found.");
                            break;
                        }
                        Goal selected = selectGoalFromList(scanner, goals);
                        if (selected == null) break;

                        System.out.print("Enter new name: ");
                        String newName = scanner.nextLine().trim();

                        System.out.print("Enter new target amount: ");
                        double newTargetAmount = Double.parseDouble(scanner.nextLine().trim());

                        System.out.print("Enter new target date (YYYY-MM-DD): ");
                        Date newTargetDate;
                        try {
                            newTargetDate = Date.valueOf(scanner.nextLine().trim());
                        } catch (IllegalArgumentException e) {
                            System.out.println("Invalid date format.");
                            break;
                        }

                        System.out.print("Enter new description: ");
                        String newDescription = scanner.nextLine().trim();

                        System.out.print("Is this a fixed goal? (y/n): ");
                        boolean newIsFixed = scanner.nextLine().trim().toLowerCase().startsWith("y");

                        Goal updatedGoal = new Goal(
                                selected.getGoalId(),
                                selected.getUserId(),
                                newName,
                                newDescription,
                                newTargetAmount,
                                selected.getCurrentAmount(),
                                newTargetDate,
                                newIsFixed,
                                selected.getStatus());

                        goalDAO.updateGoal(updatedGoal);
                        System.out.println("Goal updated.");
                        break;
                    }

                    case 5: {
                        List<Goal> goals = goalDAO.getAllGoals(DEFAULT_USER_ID);
                        if (goals.isEmpty()) {
                            System.out.println("No goals found.");
                            break;
                        }
                        Goal goalToDelete = selectGoalFromList(scanner, goals);
                        if (goalToDelete == null) break;

                        System.out.print("Are you sure you want to delete this goal? (y/n): ");
                        if (scanner.nextLine().trim().toLowerCase().startsWith("y")) {
                            try {
                                goalDAO.deleteGoal(goalToDelete.getGoalId());
                                
                                // Add notification for goal deletion
                                String message = String.format("Goal deleted: %s (Target: $%.2f)", 
                                    goalToDelete.getName(), goalToDelete.getTargetAmount());
                                addNotification(message, "GOAL_DELETE");
                                
                                System.out.println("Goal deleted successfully!");
                            } catch (SQLException e) {
                                System.out.println("Error deleting goal: " + e.getMessage());
                                addNotification("Failed to delete goal: " + e.getMessage(), "ERROR");
                            }
                        } else {
                            System.out.println("Deletion canceled.");
                        }
                        break;
                    }

                    case 6:
                        return;

                    default:
                        System.out.println("Invalid option. Choose between 1–6.");
                }
            } catch (SQLException e) {
                System.out.println("Database error: " + e.getMessage());
            }
        }
    }

    private static void checkNotifications() {
        try {
            int unreadCount = NotificationDAO.getUnreadNotificationCount(DEFAULT_USER_ID);
            if (unreadCount > 0) {
                System.out.println("\n🔔 You have " + unreadCount + " new notification" + (unreadCount > 1 ? "s" : "") + ". Type '5' to view.");
            }
        } catch (SQLException e) {
            System.out.println("Error checking notifications: " + e.getMessage());
        }
    }

    private static void addNotification(String message, String type) {
        try {
            // Map our notification types to the allowed database types
            String dbType;
            switch (type) {
                case "WARNING":
                case "ALERT":
                case "SUCCESS":
                    dbType = type; // These are valid types in the database
                    break;
                case "EXPENSE":
                case "INCOME":
                case "GOAL":
                case "GOAL_UPDATE":
                case "GOAL_DELETE":
                default:
                    dbType = "INFO"; // Map all other types to INFO
                    break;
            }
            
            Notification notification = new Notification(DEFAULT_USER_ID, message, dbType);
            NotificationDAO.addNotification(notification);
        } catch (SQLException e) {
            System.err.println("Failed to add notification: " + e.getMessage());
        }
    }

    private static void displayNotifications(List<Notification> notifications) {
        System.out.println("\n" + "=".repeat(40));
        System.out.println("NOTIFICATIONS");
        System.out.println("=".repeat(40));
        
        for (Notification notification : notifications) {
            String status = notification.isRead() ? "[READ]  " : "[UNREAD]";
            String type = String.format("%-8s", notification.getType());
            String timestamp = new SimpleDateFormat("MMM dd, yyyy HH:mm").format(notification.getCreatedAt());
            
            // Add color for unread notifications
            if (!notification.isRead()) {
                System.out.print("\u001B[1m"); // Bold for unread
            }
            
            System.out.println(status + " " + type + " - " + timestamp);
            System.out.println(notification.getFormattedMessage());
            
            if (!notification.isRead()) {
                System.out.print("\u001B[0m"); // Reset formatting
            }
            
            System.out.println("-".repeat(40));
        }
    }

    private static void handleViewNotifications(Scanner scanner) {
        try {
            // Get both read and unread notifications
            List<Notification> notifications = NotificationDAO.getAllNotifications(DEFAULT_USER_ID);

            if (notifications.isEmpty()) {
                System.out.println("\nNo notifications found.");
                return;
            }

            // Display all notifications
            displayNotifications(notifications);
            
            // Mark all as read
            int unreadCount = NotificationDAO.getUnreadNotificationCount(DEFAULT_USER_ID);
            if (unreadCount > 0) {
                System.out.print("\nMark all as read? (y/n): ");
                if (scanner.nextLine().trim().toLowerCase().startsWith("y")) {
                    NotificationDAO.markAllAsRead(DEFAULT_USER_ID);
                    System.out.println("All notifications marked as read.");
                }
            }
            
            System.out.println("\nPress Enter to continue...");
            scanner.nextLine();
            
        } catch (SQLException e) {
            System.out.println("Error viewing notifications: " + e.getMessage());
            System.out.println("Press Enter to continue...");
            scanner.nextLine();
        }
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        boolean running = true;

        while (running) {
            try {
                checkNotifications();

                System.out.println("\n======== Savings Goal Tracker ========");
                System.out.println("1. Add Expense");
                System.out.println("2. Add Income");
                System.out.println("3. View Balance");
                System.out.println("4. Manage Goals");
                System.out.println("5. View Notifications");
                System.out.println("6. Exit");
                System.out.print("Choose an option: ");

                String input = scanner.nextLine().trim();
                int choice = Integer.parseInt(input);

                switch (choice) {
                    case 1 -> handleAddExpense(scanner);
                    case 2 -> handleAddIncome(scanner);
                    case 3 -> handleViewBalance();
                    case 4 -> handleManageGoals(scanner);
                    case 5 -> handleViewNotifications(scanner);
                    case 6 -> {
                        System.out.println("Exiting... Goodbye!");
                        running = false;
                    }
                    default -> System.out.println("Invalid choice. Try again.");
                }

            } catch (NumberFormatException e) {
                System.out.println("Please enter a valid number (1–6).");
            } catch (Exception e) {
                System.out.println("An error occurred: " + e.getMessage());
                e.printStackTrace();
            }
        }

        scanner.close();
    }
}