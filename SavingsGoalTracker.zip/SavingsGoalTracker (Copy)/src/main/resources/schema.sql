-- Create users table
CREATE TABLE users (
    user_id NUMBER PRIMARY KEY,
    username VARCHAR2(50) NOT NULL UNIQUE,
    creation_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Create expenses table
CREATE TABLE expenses (
    expense_id NUMBER PRIMARY KEY,
    user_id NUMBER REFERENCES users(user_id),
    amount NUMBER(10,2) NOT NULL,
    description VARCHAR2(200),
    category VARCHAR2(50),
    expense_date DATE DEFAULT CURRENT_DATE,
    creation_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Create income table
CREATE TABLE income (
    income_id NUMBER PRIMARY KEY,
    user_id NUMBER REFERENCES users(user_id),
    amount NUMBER(10,2) NOT NULL,
    description VARCHAR2(200),
    source VARCHAR2(50),
    income_date DATE DEFAULT CURRENT_DATE,
    creation_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Create goals table
CREATE TABLE goals (
    goal_id NUMBER PRIMARY KEY,
    user_id NUMBER REFERENCES users(user_id),
    name VARCHAR2(100) NOT NULL,
    target_amount NUMBER(10,2) NOT NULL,
    current_amount NUMBER(10,2) DEFAULT 0,
    target_date DATE NOT NULL,
    status VARCHAR2(20) DEFAULT 'In Progress',
    priority VARCHAR2(10) CHECK (priority IN ('High', 'Medium', 'Low')),
    creation_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Create notifications table
CREATE TABLE notifications (
    notification_id NUMBER PRIMARY KEY,
    user_id NUMBER REFERENCES users(user_id),
    message VARCHAR2(500) NOT NULL,
    type VARCHAR2(10) CHECK (type IN ('INFO', 'WARNING', 'ALERT')),
    is_read CHAR(1) DEFAULT 'N' CHECK (is_read IN ('Y', 'N')),
    creation_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Create sequences for auto-incrementing IDs
CREATE SEQUENCE user_id_seq START WITH 1 INCREMENT BY 1;
CREATE SEQUENCE expense_id_seq START WITH 1 INCREMENT BY 1;
CREATE SEQUENCE income_id_seq START WITH 1 INCREMENT BY 1;
CREATE SEQUENCE goal_id_seq START WITH 1 INCREMENT BY 1;
CREATE SEQUENCE notification_id_seq START WITH 1 INCREMENT BY 1;

-- Insert a test user
INSERT INTO users (user_id, username) VALUES (1, 'testuser');
