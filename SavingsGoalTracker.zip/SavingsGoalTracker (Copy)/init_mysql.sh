#!/bin/bash

# Database configuration
DB_USER="root"
DB_PASS="mysecret"
DB_NAME="savings_tracker"
SQL_FILE="src/main/resources/init_db.sql"

# Check if MySQL is running in Docker
if ! docker ps | grep -q mysql; then
    echo "MySQL container is not running. Please start your MySQL Docker container first."
    exit 1
fi

# Check if the database exists
if mysql -h 127.0.0.1 -u $DB_USER -p$DB_PASS -e "USE $DB_NAME" 2>/dev/null; then
    echo "Database $DB_NAME already exists. Do you want to drop and recreate it? (y/n)"
    read -r DROP_DB
    if [ "$DROP_DB" = "y" ] || [ "$DROP_DB" = "Y" ]; then
        echo "Dropping existing database..."
        mysql -h 127.0.0.1 -u $DB_USER -p$DB_PASS -e "DROP DATABASE IF EXISTS $DB_NAME;"
    else
        echo "Using existing database."
        exit 0
    fi
fi

# Create and initialize the database
echo "Initializing database..."
mysql -h 127.0.0.1 -u $DB_USER -p$DB_PASS < "$SQL_FILE"

# Check if the initialization was successful
if [ $? -eq 0 ]; then
    echo "Database initialized successfully!"
    echo "You can now connect to the database using:"
    echo "  mysql -h 127.0.0.1 -u root -p savings_tracker"
    echo "Password: mysecret"
else
    echo "Error initializing database. Please check the SQL file for errors."
    exit 1
fi
